Ad-Watch Only Flutter Project
-----------------------------

This Flutter project is a simple ad-watching + coins earning app.

Steps to use:
1. Replace the test AdMob unit ID in lib/main.dart with your own AdMob Rewarded Ad Unit ID.
2. Replace the withdraw link with your Google Form or WhatsApp link.
3. Push this folder to GitHub OR upload the ZIP to Codemagic/Appcircle to build the APK.
4. Build the APK on Codemagic (https://codemagic.io) free tier and download.

Features:
- Rewarded ad button adds coins.
- Coins saved locally with shared_preferences.
- Withdraw button opens your form link.

Note:
I cannot generate APK directly here. You must upload this project to an online builder (Codemagic/Appcircle/Replit).
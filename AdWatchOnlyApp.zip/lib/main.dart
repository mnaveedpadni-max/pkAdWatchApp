// Ad-Watch Earning App without Website
// Replace test AdMob IDs with your own before release.

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const AdWatchApp());
}

class AdWatchApp extends StatelessWidget {
  const AdWatchApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ad-Watch Earning',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _coins = 0;
  RewardedAd? _rewardedAd;
  bool _isLoadingAd = false;

  static const int coinsPerAd = 5;

  @override
  void initState() {
    super.initState();
    _loadState();
    _loadRewarded();
  }

  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _coins = prefs.getInt('coins') ?? 0;
    });
  }

  Future<void> _persistState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('coins', _coins);
  }

  void _loadRewarded() {
    if (_isLoadingAd || _rewardedAd != null) return;
    setState(() => _isLoadingAd = true);
    RewardedAd.load(
      adUnitId: _rewardedAdUnitId(),
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          setState(() {
            _rewardedAd = ad;
            _isLoadingAd = false;
          });
        },
        onAdFailedToLoad: (err) {
          setState(() => _isLoadingAd = false);
          Future.delayed(const Duration(seconds: 10), _loadRewarded);
        },
      ),
    );
  }

  String _rewardedAdUnitId() {
    // Test IDs - replace with your AdMob ID for production
    return 'ca-app-pub-3940256099942544/5224354917';
  }

  Future<void> _showRewarded() async {
    if (_rewardedAd == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ad not ready yet.')));
      _loadRewarded();
      return;
    }
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) { ad.dispose(); setState(() => _rewardedAd = null); _loadRewarded(); },
      onAdFailedToShowFullScreenContent: (ad, err) { ad.dispose(); setState(() => _rewardedAd = null); _loadRewarded(); },
    );
    _rewardedAd!.show(onUserEarnedReward: (ad, reward) async {
      setState(() { _coins += coinsPerAd; });
      await _persistState();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('You earned $coinsPerAd coins!')));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ad-Watch Earning App')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          Text('Coins: $_coins', style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _showRewarded,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Watch Ad (+5 coins)'),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () async {
              // Replace this with your withdraw form or WhatsApp link
              const withdrawLink = 'https://forms.gle/your-google-form-link';
              showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                        title: const Text('Withdraw'),
                        content: Text('Submit your withdraw request here:\\n$withdrawLink'),
                        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
                      ));
            },
            icon: const Icon(Icons.account_balance_wallet_outlined),
            label: const Text('Withdraw'),
          ),
        ]),
      ),
    );
  }
}